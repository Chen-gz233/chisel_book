
package gemmini

object Dataflow extends Enumeration {
  val OS, WS, BOTH = Value
}


