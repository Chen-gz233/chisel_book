package gemmini

object Datatype extends Enumeration {
  val int8, fp32, fp16, bf16 = Value
}